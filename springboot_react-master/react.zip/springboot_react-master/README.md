# springboot & react 
- axios 를 이용해 springboot 데이터를 호출
- build 시 react의 내용을 빌드하여 springboot 의 static 폴더에 넣음
    - localhost 로 react 접근 가능



[react, springboot] react 와 spring boot 로 구성하기, 묶어 build 하기  
https://blog.naver.com/varkiry05/221777442335
