package com.example.react.Dtos;

import lombok.Data;

@Data
public class CostomerServiceDto {

    private String cs_id;
    private String cs_type;
    private String cs_content;
    private String cs_date;
    private int cs_user;
    private String cs_images;
    private int cs_done_yn;

}
