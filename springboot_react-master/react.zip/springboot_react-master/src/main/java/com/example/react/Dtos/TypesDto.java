package com.example.react.Dtos;

import lombok.Data;

@Data
public class TypesDto {

    private String type_id;
    private String type_name;

}
