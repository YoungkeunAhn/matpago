package com.example.react.service;


public interface MemberService {
    int joinMember();
}