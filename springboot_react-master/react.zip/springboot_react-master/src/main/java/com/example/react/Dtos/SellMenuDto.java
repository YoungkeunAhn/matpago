package com.example.react.Dtos;

import lombok.Data;

@Data
public class SellMenuDto {

    private String menu_id;
    private String menu_name;
    private String menu_price;
    private String menu_type;
    private int store_id;

}
