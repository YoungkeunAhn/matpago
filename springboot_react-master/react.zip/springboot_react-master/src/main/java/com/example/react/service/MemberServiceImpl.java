package com.example.react.service;


import com.example.react.Dtos.MembersDto;
import com.example.react.repository.BoardRepository;
import com.example.react.repository.MemberRepository;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;


@Service
public class MemberServiceImpl implements MemberService {

    @Autowired
    private MemberRepository memberRepository;

    MembersDto membersDto = new MembersDto();

    @Override
    public int joinMember() {
        membersDto.setUsername("테스트123");
        membersDto.setNaverEmail("abcd@naver.com");
        membersDto.setPhoneNum("010-2651-9477");
        return memberRepository.joinMembers(membersDto);
    }



}